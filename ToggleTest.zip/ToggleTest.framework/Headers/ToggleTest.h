//
//  ToggleTest.h
//  ToggleTest
//
//  Created by Ravikanth on 19/05/18.
//  Copyright © 2018 Ravikanth. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ToggleTest.
FOUNDATION_EXPORT double ToggleTestVersionNumber;

//! Project version string for ToggleTest.
FOUNDATION_EXPORT const unsigned char ToggleTestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ToggleTest/PublicHeader.h>


